import React from 'react';

const Dashboard = () => {
	return (
		<div className="dashboard">
			<div className="card">
				<h3>Dashboard</h3>
				<p></p>
			</div>
		</div>
	);
};

export default Dashboard;
