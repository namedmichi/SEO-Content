<?php

$path = __DIR__ . '\templateTest.json';
$jsonString = file_get_contents($path);
echo $jsonString;
